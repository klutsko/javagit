package com.shop.manager;

import com.shop.bag.Bag;
import com.shop.bag.BagImpl;
import com.shop.position.Position;
import javafx.geometry.Pos;

import java.util.Arrays;

/**
 * Created by cube on 21.02.2018.
 */
public class ShopManager extends BagImpl {

    public int sum(Bag bag) throws InterruptedException {
        int sum = 0;
        int count=0;
        bag.initIterator();
        while (bag.haveNext()){

                System.out.println("PICK!!");
                count++;
                sum += bag.next().getPrice();
            if(count %3==0) {
                sort();

            }

            Thread.sleep(1000);
        }
        System.out.println("vvasha suma sostavlaet " + sum);
        return sum;
    }
}
