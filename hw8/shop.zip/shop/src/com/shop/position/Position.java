package com.shop.position;

/**
 * Created by cube on 21.02.2018.
 */
public interface Position {

    public String getName();

    public double getPrice();
}
