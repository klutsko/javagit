package com.shop.Shelf;

import com.shop.bag.BagImpl;
import com.shop.position.impl.abst.AbstractPosition;

import java.util.NoSuchElementException;

public class AppleShelf extends BagImpl implements Shelf {
    private int size;
    AbstractPosition[] abstractPositions;

    public AppleShelf(AbstractPosition[] abstractPositions) {
        this.abstractPositions = abstractPositions;
        this.size = abstractPositions.length;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public AbstractPosition[] getAbstractPositions() {
        return abstractPositions;
    }

    public void setAbstractPositions(AbstractPosition[] abstractPositions) {
        this.abstractPositions = abstractPositions;
    }

    @Override
    public boolean put(AbstractPosition position) {
        if (getNotUsedSize() != 0) {
            return true;
        } else {
            return false;
        }

    }

    @Override
    public AbstractPosition get() {
        if (size == 0){
            throw new NoSuchElementException();
        }
        size--;
        return  abstractPositions[size];
    }


    @Override
    public boolean checkAvailable() {
        if (getNotUsedSize() == 0) {
            return false;
        } else {
            return true;
        }

    }
}
