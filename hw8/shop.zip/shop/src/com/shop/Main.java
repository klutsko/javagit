package com.shop;

import com.shop.Shelf.AppleShelf;
import com.shop.Shelf.PenShelf;
import com.shop.bag.ATBPacket;
import com.shop.bag.Bag;
import com.shop.bag.BagImpl;
import com.shop.manager.ShopManager;
import com.shop.position.Position;
import com.shop.position.impl.Apple;
import com.shop.position.impl.Pen;
import com.shop.position.impl.abst.AbstractPosition;

import java.util.Scanner;

/**
 * Created by cube on 21.02.2018.
 */
public class Main {
    public static AppleShelf appleShelf = new AppleShelf(new AbstractPosition[5]);
    public static PenShelf penShelf = new PenShelf(new AbstractPosition[4]);


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Bag bag;
        System.out.println("S chem poidem vasia?");
        System.out.println("1: ATB power");
        System.out.println("2: Standart edition Galia");
        switch (scanner.nextInt()) {
            case 1:
                bag = new ATBPacket();
                break;
            case 2:
                bag = new BagImpl();
                break;
            default:
                System.out.println("sho zirkaech? pognali s rukzacom");
                bag = new BagImpl();
        }
        while (true) {
            System.out.println("Shito delaem desy?");
            System.out.println("1: go za pokupkami person-san");
            System.out.println("2: go na cassu");
            switch (scanner.nextInt()) {
                case 1:
                    doPokupki(bag);
                    break;
                case 2:
                    goNaCassu(bag);
                    break;
                default:
                    System.out.println("dich. ti vtiraech mne dich");
            }
        }
    }

    private static void doPokupki(Bag bag) {
        Scanner scanner = new Scanner(System.in);
        while (bag.getNotUsedSize() != 0) {
            System.out.println("1:Pen");
            System.out.println("2:Apple");
            System.out.println("3:dumay");
            switch (scanner.nextInt()) {
                case 1:

                        if (penShelf.checkAvailable() == true && penShelf != null) {
                            penShelf.get();
                            System.out.println("Pen size is " + penShelf.getSize());
                        } else {
                            System.out.println("There is no more pens on the shelf");
                            break;
                        }

                    bag.add(new Pen(10, "karandashik"));

                    break;

                case 2:

                        if (appleShelf.checkAvailable() == true && appleShelf != null) {
                            appleShelf.get(/*appleShelf.get()*/);
                            System.out.println("Apple size is " + appleShelf.getSize());
                        } else {
                            System.out.println("There is no more apples on the shelf");
                            break;

                    }
                    bag.add(new Apple(25, "Apple"));

                    case 3:
                        return;
                    default:
                        System.out.println("dich. ti vtiraech mne dich");

                }

            }
            System.out.println("Galia, I te sho grushick");
        }

        private static void goNaCassu (Bag bag){
            ShopManager babaGala = new ShopManager();
            try {
                babaGala.sum(bag);
                System.out.println("oi mama, hera tac dorogo");
                System.exit(0);
            } catch (InterruptedException e) {
                System.out.println("SCORUYY!!BABA GALA ");
            }
        }

    }

